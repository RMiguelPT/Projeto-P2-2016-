package pt.ipleiria.estg.dei.puzzlepets;

public class EnimigoSuportadoPorGelo extends Enimigo {

	public EnimigoSuportadoPorGelo() {
		// TODO Auto-generated constructor stub
	}

}
