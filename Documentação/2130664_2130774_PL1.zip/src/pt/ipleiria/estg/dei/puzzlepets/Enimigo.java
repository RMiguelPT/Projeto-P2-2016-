package pt.ipleiria.estg.dei.puzzlepets;

import Suportados.Suportado;

public class Enimigo extends Suportado {
	
}
