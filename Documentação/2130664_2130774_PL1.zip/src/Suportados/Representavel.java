package Suportados;

import pt.ipleiria.estg.dei.gridpanel.CellRepresentation;

public abstract class Representavel {
	protected CellRepresentation imagem;
	
	public CellRepresentation getImagem() {
		return imagem;
	}
}
