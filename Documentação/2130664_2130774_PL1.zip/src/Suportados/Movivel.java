package Suportados;

public class Movivel extends Suportado {
	
}
