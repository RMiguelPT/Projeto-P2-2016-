package Suportados;

public abstract class Combinavel extends Movivel {

	public abstract boolean combinaCom(Combinavel combinavel);

	public abstract void explodir();

}
