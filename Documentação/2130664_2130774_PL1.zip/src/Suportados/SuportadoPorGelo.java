package Suportados;

import Suportes.SuporteGelo;

public abstract class SuportadoPorGelo<S extends SuporteGelo> extends Movivel  {

	public SuportadoPorGelo() {
		super();
	}

	
}
