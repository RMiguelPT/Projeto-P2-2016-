package Poderes;

import Interfaces.Iteravel;
import Suportados.Combinavel;
import Suportados.Movivel;
import Suportados.Suportado;

public class PoderArcoIris extends Poder implements Iteravel {
	

	public PoderArcoIris() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean combinaCom(Combinavel combinavel) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public void explodir() {
		// TODO Auto-generated method stub
		
	}


}
