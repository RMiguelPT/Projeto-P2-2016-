package Poderes;

import Suportados.Representavel;
import pt.ipleiria.estg.dei.gridpanel.SingleImageCellRepresentation;

public class PoderMovimentoExtra extends Representavel {

	public PoderMovimentoExtra() {
		super();
		this.imagem = new SingleImageCellRepresentation("/imagens/poderes/movimentoExtra.png");
	}
	

}
