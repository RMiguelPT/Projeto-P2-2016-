package Poderes;

import Suportados.Combinavel;
import Suportados.Representavel;
import Suportados.Suportado;

public abstract class Poder extends Combinavel {

	public Poder() {
		// TODO Auto-generated constructor stub
	}
}
