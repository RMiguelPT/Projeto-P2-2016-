package Paineis;

import pt.ipleiria.estg.dei.gridpanel.GridPanel;

public class Painel {

	protected GridPanel grelha;

	public Painel(GridPanel grelha) {
		super();
		this.grelha = grelha;
	}


}