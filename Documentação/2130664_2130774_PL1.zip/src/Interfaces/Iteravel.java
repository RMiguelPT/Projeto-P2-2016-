package Interfaces;

public interface Iteravel {
	
	public void iterar(long millis);

}
